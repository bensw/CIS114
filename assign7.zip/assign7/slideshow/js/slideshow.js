$(document).ready(function() {
	$("#slideshow").addClass("slideshow");
});