
<?php # Script 13.3 - login.php

// Benjamin Swartz
// CIS 114 OL
// contact.php
// Chapter 11
// Assignment 6
// 4-19-2013
?>The message has been sent.